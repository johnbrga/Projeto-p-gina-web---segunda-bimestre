import styles from './Rodape.module.css';

function Rodape() {
  return (
    <footer className={styles.rodape}>
      <p>CS Majors • Portal de Counter-Strike © 2026</p>
    </footer>
  );
}

export default Rodape;