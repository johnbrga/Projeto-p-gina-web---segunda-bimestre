import styles from './CardItem.module.css';

function CardItem({ imagem, titulo, descricao }) {
  return (
    <div className={styles.card}>
      <img src={imagem} alt={titulo} className={styles.logo} />
      <div className={styles.info}>
        <h2>{titulo}</h2>
        <p>{descricao}</p>
      </div>
    </div>
  );
}

export default CardItem;