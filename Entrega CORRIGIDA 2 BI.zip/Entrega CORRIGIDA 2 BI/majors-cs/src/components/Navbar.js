import { Link } from 'react-router-dom';
import styles from './Navbar.module.css';

function Navbar() {
  return (
    <nav className={styles.navbar}>
      <h2 className={styles.logo}>CS MAJORS</h2>
      <ul className={styles.lista}>
        <li>
          <Link to="/" className={styles.link}>Início</Link>
        </li>
        <li>
          <Link to="/times" className={styles.link}>Times</Link>
        </li>
        <li>
          <Link to="/majors" className={styles.link}>Majors</Link>
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;