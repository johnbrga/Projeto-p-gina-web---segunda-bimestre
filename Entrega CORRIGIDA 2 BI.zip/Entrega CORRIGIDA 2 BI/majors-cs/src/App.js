import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Rodape from './components/Rodape';
import PaginaIn from './pages/PaginaIn';
import Times from './pages/Times';
import Majors from './pages/Majors';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<PaginaIn />} />
        <Route path="/times" element={<Times />} />
        <Route path="/majors" element={<Majors />} />
      </Routes>
      <Rodape />
    </BrowserRouter>
  );
}

export default App;