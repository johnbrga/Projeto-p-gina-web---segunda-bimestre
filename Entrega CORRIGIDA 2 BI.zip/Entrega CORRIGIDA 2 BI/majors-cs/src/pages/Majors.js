import styles from './Majors.module.css';
import CardItem from '../components/CardItem';
import columbusImg from '../assets/columbus.png';
import copenhagenImg from '../assets/copenhagen.jpg';
import rioImg from '../assets/rio.png';

function Majors() {
  return (
    <div className={styles.inicio}>
      <h1 className={styles.titulo}>Majors Históricos</h1>
      <p className={styles.subtitulo}>
        Edições marcantes de majors de CS
      </p>

      <CardItem
        imagem={columbusImg}
        titulo="MLG Columbus 2016"
        descricao="EUA - Primeiro Major conquistado pelo Brasil pela Luminosity, marcando o início da era de ouro brasileira"
      />

      <CardItem
        imagem={rioImg}
        titulo="IEM Rio Major 2022"
        descricao="Brasil - Primeiro Major sediado na América do Sul, famoso pela festa histórica da torcida brasileira"
      />

      <CardItem
        imagem={copenhagenImg}
        titulo="PGL Major Copenhagen 2024"
        descricao="Dinamarca - Primeiro Major oficial da era Counter-Strike 2, vencido pela Natus Vincere"
      />
    </div>
  );
}

export default Majors;