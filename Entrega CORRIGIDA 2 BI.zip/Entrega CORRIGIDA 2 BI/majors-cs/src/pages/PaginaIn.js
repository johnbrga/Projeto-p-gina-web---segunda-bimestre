import styles from './PaginaIn.module.css';

function PaginaIn() {
  return (
    <div className={styles.bloco}>
      <h1 className={styles.titulo}>Majors de Counter-Strike</h1>
      <p className={styles.texto}>
        Portal dedicado aos campeonatos mundiais de CS
      </p>
    </div>
  );
}

export default PaginaIn;