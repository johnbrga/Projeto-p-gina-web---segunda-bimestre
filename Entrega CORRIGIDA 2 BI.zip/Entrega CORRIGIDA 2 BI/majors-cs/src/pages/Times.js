import styles from './Times.module.css';
import CardItem from '../components/CardItem';
import furiaLogo from '../assets/furia.png';
import spiritLogo from '../assets/spirit.png';
import vitalityLogo from '../assets/vitality.png';
import naviLogo from '../assets/navi.png';

function Times() {
  return (
    <div className={styles.inicio}>
      <h1 className={styles.titulo}>Principais equipes de Counter Strike</h1>

      <CardItem
        imagem={furiaLogo}
        titulo="FURIA"
        descricao="Brasil - Principal representante brasileira no cenário mundial, ja foi finalista de Major"
      />

      <CardItem
        imagem={spiritLogo}
        titulo="Team Spirit"
        descricao="Rússia - Potência internacional, chega em quase todas as finais e é atual campeã do major"
      />

      <CardItem
        imagem={vitalityLogo}
        titulo="Team Vitality"
        descricao="França - Multicampeã na década passada mas ainda continua sendo carrasco para várias equipes fortes"
      />

      <CardItem
        imagem={naviLogo}
        titulo="Natus Vincere (NAVI)"
        descricao="Ucrânia - Um dos times mais antigos do CS, ja foram muito vitoriosos no passado, ainda continuam indo longe nas competições"
      />
    </div>
  );
}

export default Times;