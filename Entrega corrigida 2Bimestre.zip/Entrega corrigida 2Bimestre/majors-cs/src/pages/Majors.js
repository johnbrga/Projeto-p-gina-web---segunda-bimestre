import styles from './Majors.module.css';
import columbusImg from '../assets/columbus.png';
import copenhagenImg from '../assets/copenhagen.jpg';
import rioImg from '../assets/rio.png';

function Majors() {
  return (
    <div className={styles.inicio}>
      <h1 className={styles.titulo}>Majors Históricos</h1>
      <p className={styles.subtitulo}>
        Edições marcantes de majors de CS
      </p>

      <div className={styles.card}>
        <img src={columbusImg} alt="MLG Columbus 2016" className={styles.imagem} />
        <div className={styles.info}>
          <h2>MLG Columbus 2016</h2>
          <p>EUA - Primeiro Major conquistado pelo Brasil pela Luminosity, marcando o início da era de ouro brasileira</p>
        </div>
      </div>

      <div className={styles.card}>
        <img src={rioImg} alt="IEM Rio Major 2022" className={styles.imagem} />
        <div className={styles.info}>
          <h2>IEM Rio Major 2022</h2>
          <p>Brasil - Primeiro Major sediado na América do Sul, famoso pela festa histórica da torcida brasileira</p>
        </div>
      </div>

      <div className={styles.card}>
        <img src={copenhagenImg} alt="PGL Major Copenhagen 2024" className={styles.imagem} />
        <div className={styles.info}>
          <h2>PGL Major Copenhagen 2024</h2>
          <p>Dinamarca - Primeiro Major oficial da era Counter-Strike 2, vencido pela Natus Vincere </p>
        </div>
      </div>
    </div>
  );
}

export default Majors;