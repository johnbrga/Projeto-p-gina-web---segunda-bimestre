import styles from './Times.module.css';
import furiaLogo from '../assets/furia.png';
import spiritLogo from '../assets/spirit.png';
import vitalityLogo from '../assets/vitality.png';
import naviLogo from '../assets/navi.png';

function Times() {
  return (
    <div className={styles.inicio}>
      <h1 className={styles.titulo}>Principais Times de CS</h1>
      <p className={styles.subtitulo}>
        Principais equipes de Counter Strike
      </p>

      <div className={styles.lista}>
        <div className={styles.card}>
          <img src={furiaLogo} alt="Logo FURIA" className={styles.logo} />
          <div className={styles.info}>
            <h2>FURIA</h2>
            <p>Brasil • Principal representante brasileira no cenário mundial, conhecida pelo estilo agressivo.</p>
          </div>
        </div>

        <div className={styles.card}>
          <img src={spiritLogo} alt="Logo Team Spirit" className={styles.logo} />
          <div className={styles.info}>
            <h2>Team Spirit</h2>
            <p>Rússia • Potência internacional marcada pelo talento jovem e títulos de grande porte.</p>
          </div>
        </div>

        <div className={styles.card}>
          <img src={vitalityLogo} alt="Logo Team Vitality" className={styles.logo} />
          <div className={styles.info}>
            <h2>Team Vitality</h2>
            <p>França • Organização europeia multicampeã de Majors e torneios de elite.</p>
          </div>
        </div>

        <div className={styles.card}>
          <img src={naviLogo} alt="Logo NAVI" className={styles.logo} />
          <div className={styles.info}>
            <h2>Natus Vincere (NAVI)</h2>
            <p>Ucrânia • Uma das organizações mais tradicionais e vitoriosas da história do CS.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Times;